# Results: Drug Review Sentiment (UCI Drug Review)

Rows used: 127,346 | train 101,876 | test 25,470 | demo data: False

## Test-set metrics

| model                  |   accuracy |   balanced_acc |   macro_precision |   macro_recall |   macro_F1 |   weighted_F1 |   macro_ROC_AUC |    MCC |   fit_time_s |   predict_time_s |
|:-----------------------|-----------:|---------------:|------------------:|---------------:|-----------:|--------------:|----------------:|-------:|-------------:|-----------------:|
| Logistic Regression    |     0.7455 |         0.6547 |            0.6175 |         0.6547 |     0.623  |        0.7695 |          0.8619 | 0.5422 |      50.7419 |           4.9889 |
| Linear SVM             |     0.7906 |         0.6192 |            0.6168 |         0.6192 |     0.6176 |        0.7887 |          0.8498 | 0.5742 |      48.4337 |           3.7753 |
| Complement Naive Bayes |     0.7729 |         0.5789 |            0.5869 |         0.5789 |     0.5512 |        0.7541 |          0.848  | 0.5473 |      24.0024 |           3.8009 |

## Cross-validation (macro-F1)

| model                  |   cv_macro_F1_mean |   cv_macro_F1_std |
|:-----------------------|-------------------:|------------------:|
| Logistic Regression    |             0.6244 |            0.0021 |
| Linear SVM             |             0.6157 |            0.0051 |
| Complement Naive Bayes |             0.5469 |            0.0025 |

## Bootstrap 95% CI

| model                  |   macro_F1 |   CI95_low |   CI95_high |   diff_vs_best_mean |   diff_CI95_low |   diff_CI95_high |   gap_is_significant |
|:-----------------------|-----------:|-----------:|------------:|--------------------:|----------------:|-----------------:|---------------------:|
| Logistic Regression    |     0.623  |     0.6164 |      0.6292 |            nan      |        nan      |         nan      |                  nan |
| Linear SVM             |     0.6176 |     0.6115 |      0.6249 |             -0.0052 |         -0.011  |           0.0006 |                    0 |
| Complement Naive Bayes |     0.5512 |     0.5454 |      0.5578 |             -0.0718 |         -0.0794 |          -0.0638 |                    1 |

## Unseen-drug robustness

| model                  |   grouped_macro_F1 |   grouped_accuracy |   random_split_macro_F1 |
|:-----------------------|-------------------:|-------------------:|------------------------:|
| Complement Naive Bayes |             0.5294 |             0.7417 |                  0.5512 |
| Logistic Regression    |             0.6192 |             0.7327 |                  0.623  |
| Linear SVM             |             0.6148 |             0.7821 |                  0.6176 |

## Conclusion

**Best model: Logistic Regression** (macro-F1 0.623, accuracy 0.746, macro ROC-AUC 0.862).

- vs Linear SVM: macro-F1 0.618 (difference -0.005); the gap is NOT statistically significant (interval includes 0), so the two are effectively tied.
- vs Complement Naive Bayes: macro-F1 0.551 (difference -0.072); the gap is statistically meaningful (95% bootstrap interval of the difference excludes 0).

Cross-validation agrees on the ranking: Logistic Regression 0.624, Linear SVM 0.616, Complement Naive Bayes 0.547.
Per-class view: Logistic Regression: weakest class = neutral (F1 0.30), Linear SVM: weakest class = neutral (F1 0.24), Complement Naive Bayes: weakest class = neutral (F1 0.09).
On unseen drugs, macro-F1 for Logistic Regression is 0.619 vs 0.623 on the random split.

**Why Logistic Regression wins here:** it learns discriminative weights jointly on correlated unigram/bigram features (so, unlike Naive Bayes, evidence is not double-counted), regularisation controls the very high feature count, and class weighting helps the minority neutral class.
